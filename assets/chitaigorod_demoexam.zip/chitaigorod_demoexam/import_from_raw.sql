USE chitaigorod_demo;

SET NAMES utf8mb4;

INSERT IGNORE INTO roles (name)
SELECT DISTINCT TRIM(role_name)
FROM users_import_raw
WHERE TRIM(role_name) <> '';

INSERT INTO users (role_id, full_name, login, password)
SELECT
    r.role_id,
    TRIM(raw.full_name),
    TRIM(raw.login),
    TRIM(raw.password)
FROM users_import_raw raw
JOIN roles r ON r.name = TRIM(raw.role_name)
WHERE TRIM(raw.login) <> ''
ON DUPLICATE KEY UPDATE
    role_id = VALUES(role_id),
    full_name = VALUES(full_name),
    password = VALUES(password);

INSERT IGNORE INTO categories (name)
SELECT DISTINCT TRIM(category_name)
FROM products_import_raw
WHERE TRIM(category_name) <> '';

INSERT IGNORE INTO suppliers (name)
SELECT DISTINCT TRIM(supplier_name)
FROM products_import_raw
WHERE TRIM(supplier_name) <> '';

INSERT IGNORE INTO manufacturers (name)
SELECT DISTINCT TRIM(manufacturer_name)
FROM products_import_raw
WHERE TRIM(manufacturer_name) <> '';

INSERT INTO products (
    article,
    name,
    unit_name,
    price,
    supplier_id,
    manufacturer_id,
    category_id,
    discount_percent,
    stock_quantity,
    description,
    image_path
)
SELECT
    TRIM(raw.article),
    TRIM(raw.name),
    TRIM(raw.unit_name),
    CAST(REPLACE(TRIM(raw.price), ',', '.') AS DECIMAL(12,2)),
    s.supplier_id,
    m.manufacturer_id,
    c.category_id,
    CAST(REPLACE(TRIM(raw.discount_percent), ',', '.') AS DECIMAL(5,2)),
    CAST(REPLACE(TRIM(raw.stock_quantity), ',', '.') AS UNSIGNED),
    NULLIF(TRIM(raw.description), ''),
    COALESCE(NULLIF(TRIM(raw.image_path), ''), 'picture.png')
FROM products_import_raw raw
JOIN suppliers s ON s.name = TRIM(raw.supplier_name)
JOIN manufacturers m ON m.name = TRIM(raw.manufacturer_name)
JOIN categories c ON c.name = TRIM(raw.category_name)
WHERE TRIM(raw.article) <> ''
ON DUPLICATE KEY UPDATE
    name = VALUES(name),
    unit_name = VALUES(unit_name),
    price = VALUES(price),
    supplier_id = VALUES(supplier_id),
    manufacturer_id = VALUES(manufacturer_id),
    category_id = VALUES(category_id),
    discount_percent = VALUES(discount_percent),
    stock_quantity = VALUES(stock_quantity),
    description = VALUES(description),
    image_path = VALUES(image_path);

INSERT IGNORE INTO pickup_points (address)
SELECT DISTINCT TRIM(address)
FROM pickup_points_import_raw
WHERE TRIM(address) <> '';

INSERT IGNORE INTO order_statuses (name)
SELECT DISTINCT TRIM(status_name)
FROM orders_import_raw
WHERE TRIM(status_name) <> '';

INSERT INTO orders (
    order_id,
    order_date,
    delivery_date,
    pickup_point_id,
    client_name,
    receive_code,
    status_id
)
SELECT
    CAST(TRIM(raw.order_id) AS UNSIGNED),
    CASE
        WHEN TRIM(raw.order_date_text) REGEXP '^[0-9]{4}-[0-9]{2}-[0-9]{2}'
            THEN STR_TO_DATE(LEFT(TRIM(raw.order_date_text), 10), '%Y-%m-%d')
        WHEN TRIM(raw.order_date_text) REGEXP '^[0-9]{2}\\.[0-9]{2}\\.[0-9]{4}$'
            THEN STR_TO_DATE(TRIM(raw.order_date_text), '%d.%m.%Y')
        ELSE NULL
    END,
    CASE
        WHEN TRIM(raw.delivery_date_text) REGEXP '^[0-9]{4}-[0-9]{2}-[0-9]{2}'
            THEN STR_TO_DATE(LEFT(TRIM(raw.delivery_date_text), 10), '%Y-%m-%d')
        WHEN TRIM(raw.delivery_date_text) REGEXP '^[0-9]{2}\\.[0-9]{2}\\.[0-9]{4}$'
            THEN STR_TO_DATE(TRIM(raw.delivery_date_text), '%d.%m.%Y')
        ELSE NULL
    END,
    CAST(TRIM(raw.pickup_point_id) AS UNSIGNED),
    TRIM(raw.client_name),
    TRIM(raw.receive_code),
    os.status_id
FROM orders_import_raw raw
JOIN order_statuses os ON os.name = TRIM(raw.status_name)
WHERE TRIM(raw.order_id) <> ''
ON DUPLICATE KEY UPDATE
    order_date = VALUES(order_date),
    delivery_date = VALUES(delivery_date),
    pickup_point_id = VALUES(pickup_point_id),
    client_name = VALUES(client_name),
    receive_code = VALUES(receive_code),
    status_id = VALUES(status_id);

DELETE oi
FROM order_items oi
JOIN orders_import_raw raw ON CAST(TRIM(raw.order_id) AS UNSIGNED) = oi.order_id;

INSERT INTO order_items (order_id, product_id, quantity)
WITH RECURSIVE split_orders AS (
    SELECT
        CAST(TRIM(order_id) AS UNSIGNED) AS order_id,
        TRIM(SUBSTRING_INDEX(order_items_text, ',', 1)) AS article,
        TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(order_items_text, ',', 2), ',', -1)) AS quantity_text,
        TRIM(SUBSTRING(order_items_text, LENGTH(SUBSTRING_INDEX(order_items_text, ',', 2)) + 2)) AS rest
    FROM orders_import_raw
    WHERE TRIM(order_items_text) <> ''

    UNION ALL

    SELECT
        order_id,
        TRIM(SUBSTRING_INDEX(rest, ',', 1)) AS article,
        TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(rest, ',', 2), ',', -1)) AS quantity_text,
        TRIM(SUBSTRING(rest, LENGTH(SUBSTRING_INDEX(rest, ',', 2)) + 2)) AS rest
    FROM split_orders
    WHERE rest LIKE '%,%'
)
SELECT
    s.order_id,
    p.product_id,
    CAST(REPLACE(s.quantity_text, ',', '.') AS UNSIGNED)
FROM split_orders s
JOIN products p ON p.article = s.article
WHERE s.article <> ''
  AND CAST(REPLACE(s.quantity_text, ',', '.') AS UNSIGNED) > 0;
