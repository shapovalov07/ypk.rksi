import sys
import time
from decimal import Decimal, InvalidOperation
from pathlib import Path

from PIL import Image
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QIcon, QPixmap
from PyQt6.QtWidgets import (
    QApplication,
    QComboBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from db import get_connection


BASE_DIR = Path(__file__).resolve().parent
RESOURCES_DIR = BASE_DIR / "resources"
CUSTOM_IMAGES_DIR = RESOURCES_DIR / "custom_images"
LOGO_PATH = RESOURCES_DIR / "icon.png"
ICON_PATH = RESOURCES_DIR / "icon.ico"
PLACEHOLDER_PATH = RESOURCES_DIR / "picture.png"

COLOR_MAIN_BG = "#FFFFFF"
COLOR_SECOND_BG = "#ABCFCE"
COLOR_ACCENT = "#546F94"
COLOR_DISCOUNT = "#23E1EF"
COLOR_EMPTY_STOCK = "#D9D9D9"

ROLE_ADMIN = "Администратор"
ROLE_MANAGER = "Менеджер"
ROLE_CLIENT = "Авторизированный клиент"
ROLE_GUEST = "Гость"


def money(value):
    return Decimal(str(value or 0)).quantize(Decimal("0.01"))


def final_price(price, discount):
    return money(price) * (Decimal("1") - Decimal(str(discount or 0)) / Decimal("100"))


def parse_decimal(text, field_name):
    try:
        value = Decimal(text.replace(",", ".").strip())
    except (InvalidOperation, AttributeError):
        raise ValueError(f"Поле '{field_name}' должно быть числом.")
    if value < 0:
        raise ValueError(f"Поле '{field_name}' не может быть отрицательным.")
    return value


def parse_int(text, field_name):
    try:
        value = int(text.strip())
    except (ValueError, AttributeError):
        raise ValueError(f"Поле '{field_name}' должно быть целым числом.")
    if value < 0:
        raise ValueError(f"Поле '{field_name}' не может быть отрицательным.")
    return value


def run_query(sql, params=(), fetch=False, dictionary=True):
    conn = get_connection()
    try:
        cur = conn.cursor(dictionary=dictionary)
        cur.execute(sql, params)
        if fetch:
            return cur.fetchall()
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def load_lookup(table, id_column):
    return run_query(f"SELECT {id_column} AS id, name FROM {table} ORDER BY name", fetch=True)


def image_path(name):
    if not name:
        return PLACEHOLDER_PATH
    path = RESOURCES_DIR / name
    if path.exists():
        return path
    path = BASE_DIR / name
    if path.exists():
        return path
    return PLACEHOLDER_PATH


class BaseWindow(QMainWindow):
    def apply_base_style(self):
        self.setStyleSheet(
            f"""
            QMainWindow, QDialog, QWidget {{
                background-color: {COLOR_MAIN_BG};
                font-family: "Comic Sans MS";
                font-size: 12px;
            }}
            QLineEdit, QTextEdit, QComboBox {{
                border: 1px solid #888888;
                border-radius: 4px;
                padding: 6px;
                background: white;
            }}
            QPushButton {{
                background-color: {COLOR_ACCENT};
                color: white;
                border: none;
                border-radius: 4px;
                padding: 7px 12px;
            }}
            QPushButton:disabled {{
                background-color: #999999;
            }}
            QTableWidget {{
                gridline-color: #888888;
                selection-background-color: {COLOR_ACCENT};
                selection-color: white;
            }}
            """
        )


class LoginWindow(BaseWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ЧитайГород - вход")
        self.setWindowIcon(QIcon(str(ICON_PATH)))
        self.apply_base_style()
        self.resize(520, 360)

        root = QWidget()
        layout = QVBoxLayout(root)
        layout.setContentsMargins(32, 28, 32, 28)
        layout.setSpacing(14)

        logo = QLabel()
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        if LOGO_PATH.exists():
            logo.setPixmap(QPixmap(str(LOGO_PATH)).scaled(96, 96, Qt.AspectRatioMode.KeepAspectRatio))
        layout.addWidget(logo)

        title = QLabel("ООО «ЧитайГород»")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title_font = QFont("Comic Sans MS", 18, QFont.Weight.Bold)
        title.setFont(title_font)
        layout.addWidget(title)

        self.login_edit = QLineEdit()
        self.login_edit.setPlaceholderText("Логин")
        self.password_edit = QLineEdit()
        self.password_edit.setPlaceholderText("Пароль")
        self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        layout.addWidget(self.login_edit)
        layout.addWidget(self.password_edit)

        buttons = QHBoxLayout()
        enter_button = QPushButton("Войти")
        guest_button = QPushButton("Войти как гость")
        enter_button.clicked.connect(self.authorize)
        guest_button.clicked.connect(self.open_guest)
        buttons.addWidget(enter_button)
        buttons.addWidget(guest_button)
        layout.addLayout(buttons)

        self.setCentralWidget(root)

    def authorize(self):
        login = self.login_edit.text().strip()
        password = self.password_edit.text().strip()
        if not login or not password:
            QMessageBox.warning(self, "Ошибка входа", "Введите логин и пароль.")
            return
        rows = run_query(
            """
            SELECT u.user_id, u.full_name, r.name AS role_name
            FROM users u
            JOIN roles r ON r.role_id = u.role_id
            WHERE u.login = %s AND u.password = %s
            """,
            (login, password),
            fetch=True,
        )
        if not rows:
            QMessageBox.critical(self, "Ошибка входа", "Пользователь с такими данными не найден.")
            return
        self.open_products(rows[0]["role_name"], rows[0]["full_name"])

    def open_guest(self):
        self.open_products(ROLE_GUEST, "Гость")

    def open_products(self, role, full_name):
        self.products_window = ProductsWindow(role, full_name, self)
        self.products_window.show()
        self.hide()


class ProductsWindow(BaseWindow):
    def __init__(self, role, full_name, login_window):
        super().__init__()
        self.role = role
        self.full_name = full_name
        self.login_window = login_window
        self.edit_dialog_open = False
        self.setWindowTitle("ЧитайГород - товары")
        self.setWindowIcon(QIcon(str(ICON_PATH)))
        self.apply_base_style()
        self.resize(1320, 760)

        root = QWidget()
        layout = QVBoxLayout(root)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(10)

        header = QHBoxLayout()
        logo = QLabel()
        if LOGO_PATH.exists():
            logo.setPixmap(QPixmap(str(LOGO_PATH)).scaled(52, 52, Qt.AspectRatioMode.KeepAspectRatio))
        header.addWidget(logo)
        title = QLabel("Список товаров")
        title.setFont(QFont("Comic Sans MS", 18, QFont.Weight.Bold))
        header.addWidget(title)
        header.addStretch()
        header.addWidget(QLabel(f"{self.full_name}"))
        logout_button = QPushButton("Выйти")
        logout_button.clicked.connect(self.logout)
        header.addWidget(logout_button)
        layout.addLayout(header)

        self.controls = QHBoxLayout()
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Поиск")
        self.sort_combo = QComboBox()
        self.sort_combo.addItems([
            "Без сортировки",
            "Цена по возрастанию",
            "Цена по убыванию",
            "Остаток по возрастанию",
            "Остаток по убыванию",
        ])
        self.discount_combo = QComboBox()
        self.discount_combo.addItems(["Все диапазоны", "0-12,99%", "13-16,99%", "17% и более"])
        self.add_button = QPushButton("Добавить товар")
        self.delete_button = QPushButton("Удалить товар")
        self.orders_button = QPushButton("Заказы")

        self.search_edit.textChanged.connect(self.load_products)
        self.sort_combo.currentIndexChanged.connect(self.load_products)
        self.discount_combo.currentIndexChanged.connect(self.load_products)
        self.add_button.clicked.connect(self.add_product)
        self.delete_button.clicked.connect(self.delete_product)
        self.orders_button.clicked.connect(self.open_orders)

        if self.role in (ROLE_MANAGER, ROLE_ADMIN):
            self.controls.addWidget(self.search_edit, 2)
            self.controls.addWidget(self.sort_combo, 1)
            self.controls.addWidget(self.discount_combo, 1)
            self.controls.addWidget(self.orders_button)
        if self.role == ROLE_ADMIN:
            self.controls.addWidget(self.add_button)
            self.controls.addWidget(self.delete_button)
        if self.role in (ROLE_MANAGER, ROLE_ADMIN):
            layout.addLayout(self.controls)

        self.table = QTableWidget()
        self.table.setColumnCount(11)
        self.table.setHorizontalHeaderLabels([
            "Фото",
            "Артикул",
            "Наименование",
            "Категория",
            "Описание",
            "Производитель",
            "Поставщик",
            "Цена",
            "Ед.",
            "Остаток",
            "Скидка",
        ])
        self.table.verticalHeader().setDefaultSectionSize(82)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.doubleClicked.connect(self.edit_selected_product)
        layout.addWidget(self.table)

        self.setCentralWidget(root)
        self.load_products()

    def logout(self):
        self.login_window.show()
        self.close()

    def build_filter(self):
        where = []
        params = []
        if self.role in (ROLE_MANAGER, ROLE_ADMIN):
            search = self.search_edit.text().strip()
            if search:
                like = f"%{search}%"
                where.append(
                    """
                    (p.article LIKE %s OR p.name LIKE %s OR p.description LIKE %s
                     OR c.name LIKE %s OR s.name LIKE %s OR m.name LIKE %s OR p.unit_name LIKE %s)
                    """
                )
                params.extend([like] * 7)
            discount_index = self.discount_combo.currentIndex()
            if discount_index == 1:
                where.append("p.discount_percent >= 0 AND p.discount_percent < 13")
            elif discount_index == 2:
                where.append("p.discount_percent >= 13 AND p.discount_percent < 17")
            elif discount_index == 3:
                where.append("p.discount_percent >= 17")

        clause = "WHERE " + " AND ".join(where) if where else ""
        order_by = "ORDER BY p.product_id"
        if self.role in (ROLE_MANAGER, ROLE_ADMIN):
            sort_index = self.sort_combo.currentIndex()
            order_by = {
                1: "ORDER BY p.price ASC, p.name",
                2: "ORDER BY p.price DESC, p.name",
                3: "ORDER BY p.stock_quantity ASC, p.name",
                4: "ORDER BY p.stock_quantity DESC, p.name",
            }.get(sort_index, order_by)
        return clause, params, order_by

    def load_products(self):
        clause, params, order_by = self.build_filter()
        rows = run_query(
            f"""
            SELECT
                p.product_id, p.article, p.name, p.unit_name, p.price,
                p.discount_percent, p.stock_quantity, p.description, p.image_path,
                c.name AS category_name,
                s.name AS supplier_name,
                m.name AS manufacturer_name
            FROM products p
            JOIN categories c ON c.category_id = p.category_id
            JOIN suppliers s ON s.supplier_id = p.supplier_id
            JOIN manufacturers m ON m.manufacturer_id = p.manufacturer_id
            {clause}
            {order_by}
            """,
            tuple(params),
            fetch=True,
        )
        self.table.setRowCount(len(rows))
        for row_index, row in enumerate(rows):
            self.table.setRowHeight(row_index, 82)
            self.table.setVerticalHeaderItem(row_index, QTableWidgetItem(str(row["product_id"])))
            self.fill_product_row(row_index, row)
        self.table.resizeColumnsToContents()
        self.table.setColumnWidth(2, 250)
        self.table.setColumnWidth(4, 330)

    def row_color(self, row):
        if int(row["stock_quantity"]) == 0:
            return QColor(COLOR_EMPTY_STOCK)
        if Decimal(str(row["discount_percent"])) > Decimal("25"):
            return QColor(COLOR_DISCOUNT)
        return QColor(COLOR_MAIN_BG)

    def fill_product_row(self, row_index, row):
        bg_color = self.row_color(row)

        photo = QLabel()
        photo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        photo.setPixmap(QPixmap(str(image_path(row["image_path"]))).scaled(56, 76, Qt.AspectRatioMode.KeepAspectRatio))
        photo.setStyleSheet(f"background-color: {bg_color.name()};")
        self.table.setCellWidget(row_index, 0, photo)

        values = [
            row["article"],
            row["name"],
            row["category_name"],
            row["description"] or "",
            row["manufacturer_name"],
            row["supplier_name"],
            "",
            row["unit_name"],
            str(row["stock_quantity"]),
            f"{money(row['discount_percent'])}%",
        ]
        for column, value in enumerate(values, start=1):
            item = QTableWidgetItem(str(value))
            item.setBackground(bg_color)
            item.setData(Qt.ItemDataRole.UserRole, row["product_id"])
            self.table.setItem(row_index, column, item)

        price_label = QLabel()
        price_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        price = money(row["price"])
        discount = money(row["discount_percent"])
        if discount > 0:
            result = final_price(price, discount).quantize(Decimal("0.01"))
            price_label.setText(f"<span style='color:red;text-decoration:line-through'>{price}</span><br><span style='color:black'>{result}</span>")
        else:
            price_label.setText(str(price))
        price_label.setStyleSheet(f"background-color: {bg_color.name()};")
        self.table.setCellWidget(row_index, 7, price_label)

    def selected_product_id(self):
        row = self.table.currentRow()
        if row < 0:
            return None
        item = self.table.item(row, 1)
        return item.data(Qt.ItemDataRole.UserRole) if item else None

    def add_product(self):
        self.open_product_dialog(None)

    def edit_selected_product(self):
        if self.role != ROLE_ADMIN:
            return
        product_id = self.selected_product_id()
        if product_id:
            self.open_product_dialog(product_id)

    def open_product_dialog(self, product_id):
        if self.edit_dialog_open:
            QMessageBox.warning(self, "Редактирование товара", "Сейчас уже открыта форма товара.")
            return
        self.edit_dialog_open = True
        self.product_dialog = ProductDialog(self, product_id)
        self.product_dialog.finished.connect(lambda _: self._product_dialog_closed())
        self.product_dialog.saved.connect(self.load_products)
        self.product_dialog.show()

    def _product_dialog_closed(self):
        self.edit_dialog_open = False
        self.product_dialog = None

    def delete_product(self):
        product_id = self.selected_product_id()
        if not product_id:
            QMessageBox.warning(self, "Удаление товара", "Выберите товар для удаления.")
            return
        rows = run_query("SELECT COUNT(*) AS cnt FROM order_items WHERE product_id = %s", (product_id,), fetch=True)
        if rows[0]["cnt"] > 0:
            QMessageBox.critical(self, "Удаление товара", "Товар присутствует в заказе, поэтому удалить его нельзя.")
            return
        answer = QMessageBox.question(self, "Удаление товара", "Удалить выбранный товар?")
        if answer != QMessageBox.StandardButton.Yes:
            return
        run_query("DELETE FROM products WHERE product_id = %s", (product_id,), dictionary=False)
        self.load_products()

    def open_orders(self):
        self.orders_window = OrdersWindow(self.role, self.full_name, self)
        self.orders_window.show()


class ProductDialog(QDialog):
    saved = pyqtSignal()

    def __init__(self, parent, product_id=None):
        super().__init__(parent)
        self.product_id = product_id
        self.current_image = ""
        self.new_image_source = None
        self.setWindowTitle("Редактирование товара" if product_id else "Добавление товара")
        self.setWindowIcon(QIcon(str(ICON_PATH)))
        self.setModal(False)
        self.resize(620, 640)

        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.id_label = QLabel("Автоматически")
        self.article_edit = QLineEdit()
        self.name_edit = QLineEdit()
        self.unit_edit = QLineEdit()
        self.price_edit = QLineEdit()
        self.category_combo = QComboBox()
        self.supplier_combo = QComboBox()
        self.manufacturer_combo = QComboBox()
        self.stock_edit = QLineEdit()
        self.discount_edit = QLineEdit()
        self.description_edit = QTextEdit()
        self.image_label = QLabel("picture.png")
        self.image_label.setWordWrap(True)
        image_button = QPushButton("Выбрать изображение")
        image_button.clicked.connect(self.choose_image)

        self.fill_combo(self.category_combo, "categories", "category_id")
        self.fill_combo(self.supplier_combo, "suppliers", "supplier_id")
        self.fill_combo(self.manufacturer_combo, "manufacturers", "manufacturer_id")

        form.addRow("ID товара", self.id_label)
        form.addRow("Артикул", self.article_edit)
        form.addRow("Наименование", self.name_edit)
        form.addRow("Категория", self.category_combo)
        form.addRow("Описание", self.description_edit)
        form.addRow("Производитель", self.manufacturer_combo)
        form.addRow("Поставщик", self.supplier_combo)
        form.addRow("Цена", self.price_edit)
        form.addRow("Единица измерения", self.unit_edit)
        form.addRow("Количество на складе", self.stock_edit)
        form.addRow("Действующая скидка", self.discount_edit)
        form.addRow("Фото", self.image_label)
        form.addRow("", image_button)
        layout.addLayout(form)

        buttons = QHBoxLayout()
        save_button = QPushButton("Сохранить")
        cancel_button = QPushButton("Назад")
        save_button.clicked.connect(self.save)
        cancel_button.clicked.connect(self.close)
        buttons.addStretch()
        buttons.addWidget(save_button)
        buttons.addWidget(cancel_button)
        layout.addLayout(buttons)

        if product_id:
            self.load_product()

    def fill_combo(self, combo, table, id_column):
        combo.clear()
        for row in load_lookup(table, id_column):
            combo.addItem(row["name"], row["id"])

    def set_combo_value(self, combo, value):
        index = combo.findData(value)
        if index >= 0:
            combo.setCurrentIndex(index)

    def load_product(self):
        rows = run_query(
            "SELECT * FROM products WHERE product_id = %s",
            (self.product_id,),
            fetch=True,
        )
        if not rows:
            QMessageBox.critical(self, "Ошибка", "Товар не найден.")
            self.close()
            return
        row = rows[0]
        self.id_label.setText(str(row["product_id"]))
        self.article_edit.setText(row["article"])
        self.name_edit.setText(row["name"])
        self.unit_edit.setText(row["unit_name"])
        self.price_edit.setText(str(money(row["price"])))
        self.stock_edit.setText(str(row["stock_quantity"]))
        self.discount_edit.setText(str(money(row["discount_percent"])))
        self.description_edit.setPlainText(row["description"] or "")
        self.current_image = row["image_path"] or "picture.png"
        self.image_label.setText(self.current_image)
        self.set_combo_value(self.category_combo, row["category_id"])
        self.set_combo_value(self.supplier_combo, row["supplier_id"])
        self.set_combo_value(self.manufacturer_combo, row["manufacturer_id"])

    def choose_image(self):
        path, _ = QFileDialog.getOpenFileName(self, "Выберите изображение", "", "Images (*.png *.jpg *.jpeg)")
        if not path:
            return
        self.new_image_source = Path(path)
        self.image_label.setText(self.new_image_source.name)

    def save_image(self):
        if self.new_image_source is None:
            return self.current_image or "picture.png"
        CUSTOM_IMAGES_DIR.mkdir(exist_ok=True)
        suffix = self.new_image_source.suffix.lower()
        target_name = f"product_{int(time.time())}{suffix}"
        target_path = CUSTOM_IMAGES_DIR / target_name
        with Image.open(self.new_image_source) as img:
            img.thumbnail((300, 200))
            img.save(target_path)
        if self.current_image.startswith("custom_images/"):
            old_path = RESOURCES_DIR / self.current_image
            if old_path.exists():
                old_path.unlink()
        return f"custom_images/{target_name}"

    def validate(self):
        data = {
            "article": self.article_edit.text().strip(),
            "name": self.name_edit.text().strip(),
            "unit_name": self.unit_edit.text().strip(),
            "price": parse_decimal(self.price_edit.text(), "Цена"),
            "category_id": self.category_combo.currentData(),
            "supplier_id": self.supplier_combo.currentData(),
            "manufacturer_id": self.manufacturer_combo.currentData(),
            "stock_quantity": parse_int(self.stock_edit.text(), "Количество на складе"),
            "discount_percent": parse_decimal(self.discount_edit.text(), "Действующая скидка"),
            "description": self.description_edit.toPlainText().strip(),
        }
        required = ["article", "name", "unit_name"]
        for field in required:
            if not data[field]:
                raise ValueError("Заполните артикул, наименование и единицу измерения.")
        return data

    def save(self):
        try:
            data = self.validate()
            data["image_path"] = self.save_image()
            if self.product_id:
                run_query(
                    """
                    UPDATE products
                    SET article=%s, name=%s, unit_name=%s, price=%s, supplier_id=%s,
                        manufacturer_id=%s, category_id=%s, discount_percent=%s,
                        stock_quantity=%s, description=%s, image_path=%s
                    WHERE product_id=%s
                    """,
                    (
                        data["article"],
                        data["name"],
                        data["unit_name"],
                        data["price"],
                        data["supplier_id"],
                        data["manufacturer_id"],
                        data["category_id"],
                        data["discount_percent"],
                        data["stock_quantity"],
                        data["description"],
                        data["image_path"],
                        self.product_id,
                    ),
                    dictionary=False,
                )
            else:
                run_query(
                    """
                    INSERT INTO products (
                        article, name, unit_name, price, supplier_id, manufacturer_id,
                        category_id, discount_percent, stock_quantity, description, image_path
                    )
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """,
                    (
                        data["article"],
                        data["name"],
                        data["unit_name"],
                        data["price"],
                        data["supplier_id"],
                        data["manufacturer_id"],
                        data["category_id"],
                        data["discount_percent"],
                        data["stock_quantity"],
                        data["description"],
                        data["image_path"],
                    ),
                    dictionary=False,
                )
            self.saved.emit()
            self.close()
        except Exception as exc:
            QMessageBox.critical(self, "Ошибка сохранения", str(exc))


class OrdersWindow(BaseWindow):
    def __init__(self, role, full_name, products_window):
        super().__init__()
        self.role = role
        self.full_name = full_name
        self.products_window = products_window
        self.setWindowTitle("ЧитайГород - заказы")
        self.setWindowIcon(QIcon(str(ICON_PATH)))
        self.apply_base_style()
        self.resize(1120, 620)

        root = QWidget()
        layout = QVBoxLayout(root)
        header = QHBoxLayout()
        title = QLabel("Заказы")
        title.setFont(QFont("Comic Sans MS", 18, QFont.Weight.Bold))
        header.addWidget(title)
        header.addStretch()
        header.addWidget(QLabel(self.full_name))
        back_button = QPushButton("Назад")
        back_button.clicked.connect(self.close)
        header.addWidget(back_button)
        layout.addLayout(header)

        if self.role == ROLE_ADMIN:
            actions = QHBoxLayout()
            add_button = QPushButton("Добавить заказ")
            edit_button = QPushButton("Редактировать заказ")
            delete_button = QPushButton("Удалить заказ")
            add_button.clicked.connect(lambda: self.open_order_dialog(None))
            edit_button.clicked.connect(self.edit_order)
            delete_button.clicked.connect(self.delete_order)
            actions.addWidget(add_button)
            actions.addWidget(edit_button)
            actions.addWidget(delete_button)
            actions.addStretch()
            layout.addLayout(actions)

        self.table = QTableWidget()
        self.table.setColumnCount(8)
        self.table.setHorizontalHeaderLabels([
            "Номер",
            "Артикулы",
            "Дата заказа",
            "Дата выдачи",
            "Пункт выдачи",
            "Клиент",
            "Код",
            "Статус",
        ])
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.doubleClicked.connect(self.edit_order)
        layout.addWidget(self.table)
        self.setCentralWidget(root)
        self.load_orders()

    def load_orders(self):
        rows = run_query(
            """
            SELECT
                o.order_id,
                o.order_date,
                o.delivery_date,
                pp.address,
                o.client_name,
                o.receive_code,
                os.name AS status_name,
                GROUP_CONCAT(CONCAT(p.article, ', ', oi.quantity) ORDER BY p.article SEPARATOR ', ') AS items
            FROM orders o
            JOIN pickup_points pp ON pp.pickup_point_id = o.pickup_point_id
            JOIN order_statuses os ON os.status_id = o.status_id
            LEFT JOIN order_items oi ON oi.order_id = o.order_id
            LEFT JOIN products p ON p.product_id = oi.product_id
            GROUP BY o.order_id, o.order_date, o.delivery_date, pp.address, o.client_name, o.receive_code, os.name
            ORDER BY o.order_id
            """,
            fetch=True,
        )
        self.table.setRowCount(len(rows))
        for row_index, row in enumerate(rows):
            values = [
                row["order_id"],
                row["items"] or "",
                row["order_date"] or "",
                row["delivery_date"] or "",
                row["address"],
                row["client_name"],
                row["receive_code"],
                row["status_name"],
            ]
            for column, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setData(Qt.ItemDataRole.UserRole, row["order_id"])
                self.table.setItem(row_index, column, item)
        self.table.resizeColumnsToContents()
        self.table.setColumnWidth(1, 260)
        self.table.setColumnWidth(4, 280)

    def selected_order_id(self):
        row = self.table.currentRow()
        if row < 0:
            return None
        item = self.table.item(row, 0)
        return item.data(Qt.ItemDataRole.UserRole) if item else None

    def edit_order(self):
        if self.role != ROLE_ADMIN:
            return
        order_id = self.selected_order_id()
        if order_id:
            self.open_order_dialog(order_id)

    def open_order_dialog(self, order_id):
        dialog = OrderDialog(self, order_id)
        dialog.saved.connect(self.load_orders)
        dialog.exec()

    def delete_order(self):
        order_id = self.selected_order_id()
        if not order_id:
            QMessageBox.warning(self, "Удаление заказа", "Выберите заказ для удаления.")
            return
        answer = QMessageBox.question(self, "Удаление заказа", "Удалить выбранный заказ?")
        if answer != QMessageBox.StandardButton.Yes:
            return
        run_query("DELETE FROM orders WHERE order_id = %s", (order_id,), dictionary=False)
        self.load_orders()


class OrderDialog(QDialog):
    saved = pyqtSignal()

    def __init__(self, parent, order_id=None):
        super().__init__(parent)
        self.order_id = order_id
        self.setWindowTitle("Редактирование заказа" if order_id else "Добавление заказа")
        self.setWindowIcon(QIcon(str(ICON_PATH)))
        self.resize(620, 420)

        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.order_id_edit = QLineEdit()
        self.order_id_edit.setReadOnly(True)
        self.items_edit = QLineEdit()
        self.items_edit.setPlaceholderText("А112Т4, 2, G843H5, 1")
        self.status_combo = QComboBox()
        self.pickup_combo = QComboBox()
        self.order_date_edit = QLineEdit()
        self.order_date_edit.setPlaceholderText("YYYY-MM-DD")
        self.delivery_date_edit = QLineEdit()
        self.delivery_date_edit.setPlaceholderText("YYYY-MM-DD")
        self.client_edit = QLineEdit()
        self.code_edit = QLineEdit()

        for row in load_lookup("order_statuses", "status_id"):
            self.status_combo.addItem(row["name"], row["id"])
        pickup_rows = run_query("SELECT pickup_point_id AS id, address AS name FROM pickup_points ORDER BY pickup_point_id", fetch=True)
        for row in pickup_rows:
            self.pickup_combo.addItem(row["name"], row["id"])

        form.addRow("Номер заказа", self.order_id_edit)
        form.addRow("Артикул", self.items_edit)
        form.addRow("Статус заказа", self.status_combo)
        form.addRow("Адрес пункта выдачи", self.pickup_combo)
        form.addRow("Дата заказа", self.order_date_edit)
        form.addRow("Дата выдачи", self.delivery_date_edit)
        form.addRow("ФИО клиента", self.client_edit)
        form.addRow("Код получения", self.code_edit)
        layout.addLayout(form)

        buttons = QHBoxLayout()
        save_button = QPushButton("Сохранить")
        cancel_button = QPushButton("Назад")
        save_button.clicked.connect(self.save)
        cancel_button.clicked.connect(self.close)
        buttons.addStretch()
        buttons.addWidget(save_button)
        buttons.addWidget(cancel_button)
        layout.addLayout(buttons)

        if order_id:
            self.load_order()
        else:
            rows = run_query("SELECT COALESCE(MAX(order_id), 0) + 1 AS next_id FROM orders", fetch=True)
            self.order_id_edit.setText(str(rows[0]["next_id"]))

    def set_combo_value(self, combo, value):
        index = combo.findData(value)
        if index >= 0:
            combo.setCurrentIndex(index)

    def load_order(self):
        rows = run_query("SELECT * FROM orders WHERE order_id = %s", (self.order_id,), fetch=True)
        if not rows:
            QMessageBox.critical(self, "Ошибка", "Заказ не найден.")
            self.close()
            return
        row = rows[0]
        items = run_query(
            """
            SELECT p.article, oi.quantity
            FROM order_items oi
            JOIN products p ON p.product_id = oi.product_id
            WHERE oi.order_id = %s
            ORDER BY oi.order_item_id
            """,
            (self.order_id,),
            fetch=True,
        )
        self.order_id_edit.setText(str(row["order_id"]))
        self.items_edit.setText(", ".join(f"{item['article']}, {item['quantity']}" for item in items))
        self.order_date_edit.setText(str(row["order_date"] or ""))
        self.delivery_date_edit.setText(str(row["delivery_date"] or ""))
        self.client_edit.setText(row["client_name"])
        self.code_edit.setText(row["receive_code"])
        self.set_combo_value(self.status_combo, row["status_id"])
        self.set_combo_value(self.pickup_combo, row["pickup_point_id"])

    def parse_items(self):
        parts = [part.strip() for part in self.items_edit.text().split(",")]
        if len(parts) < 2 or len(parts) % 2 != 0:
            raise ValueError("Введите артикулы в формате: А112Т4, 2, G843H5, 1.")
        result = []
        for index in range(0, len(parts), 2):
            article = parts[index]
            quantity = parse_int(parts[index + 1], "Количество товара в заказе")
            if quantity <= 0:
                raise ValueError("Количество товара в заказе должно быть больше нуля.")
            product = run_query("SELECT product_id FROM products WHERE article = %s", (article,), fetch=True)
            if not product:
                raise ValueError(f"Товар с артикулом '{article}' не найден.")
            result.append((product[0]["product_id"], quantity))
        return result

    def save(self):
        try:
            order_id = parse_int(self.order_id_edit.text(), "Номер заказа")
            items = self.parse_items()
            if not self.client_edit.text().strip() or not self.code_edit.text().strip():
                raise ValueError("Заполните ФИО клиента и код получения.")
            if self.order_id:
                run_query(
                    """
                    UPDATE orders
                    SET order_date=%s, delivery_date=%s, pickup_point_id=%s,
                        client_name=%s, receive_code=%s, status_id=%s
                    WHERE order_id=%s
                    """,
                    (
                        self.order_date_edit.text().strip() or None,
                        self.delivery_date_edit.text().strip() or None,
                        self.pickup_combo.currentData(),
                        self.client_edit.text().strip(),
                        self.code_edit.text().strip(),
                        self.status_combo.currentData(),
                        order_id,
                    ),
                    dictionary=False,
                )
            else:
                run_query(
                    """
                    INSERT INTO orders (
                        order_id, order_date, delivery_date, pickup_point_id,
                        client_name, receive_code, status_id
                    )
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                    """,
                    (
                        order_id,
                        self.order_date_edit.text().strip() or None,
                        self.delivery_date_edit.text().strip() or None,
                        self.pickup_combo.currentData(),
                        self.client_edit.text().strip(),
                        self.code_edit.text().strip(),
                        self.status_combo.currentData(),
                    ),
                    dictionary=False,
                )
            run_query("DELETE FROM order_items WHERE order_id = %s", (order_id,), dictionary=False)
            for product_id, quantity in items:
                run_query(
                    "INSERT INTO order_items (order_id, product_id, quantity) VALUES (%s, %s, %s)",
                    (order_id, product_id, quantity),
                    dictionary=False,
                )
            self.saved.emit()
            self.close()
        except Exception as exc:
            QMessageBox.critical(self, "Ошибка сохранения", str(exc))


def main():
    app = QApplication(sys.argv)
    app.setFont(QFont("Comic Sans MS", 10))
    if ICON_PATH.exists():
        app.setWindowIcon(QIcon(str(ICON_PATH)))
    window = LoginWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
