# Лабораторная работа: Python + PyQt6 + MySQL через XAMPP (Вариант 1, ООО «ЧитайГород»)

## Результат лабораторной
После выполнения будет готово приложение для демонстрационного экзамена по варианту ООО «ЧитайГород»:
- база данных MySQL в 3НФ;
- импорт исходных данных из Excel-файлов;
- окно авторизации с ролями гость, авторизированный клиент, менеджер, администратор;
- список товаров с фото, категорией, описанием, производителем, поставщиком, ценой, единицей измерения, остатком и скидкой;
- подсветка строк по скидке и отсутствию товара на складе;
- поиск, сортировка и фильтрация для менеджера и администратора;
- добавление, редактирование и удаление товаров для администратора;
- список заказов для менеджера и администратора;
- добавление, редактирование и удаление заказов для администратора;
- SQL-скрипт, исходный код, ресурсы, ER-диаграмма и инструкция для запуска в VS Code.

---

## Шаг 1. Создайте папку проекта
### Что делаем
Создайте папку проекта и откройте ее в VS Code.

### Команды/код
```cmd
cd C:\
mkdir chitaigorod_demoexam
cd chitaigorod_demoexam
mkdir resources
mkdir screenshots
```

Скопируйте в папку `resources` файлы из архива задания:
- `Tovar.xlsx`;
- `user_import.xlsx`;
- `Заказ_import.xlsx`;
- `Пункты выдачи_import.xlsx`;
- `icon.png`;
- `icon.ico`;
- `picture.png`;
- изображения книг `1.jpg` - `20.jpg`.

---

## Шаг 2. Запустите XAMPP
### Что делаем
Запустите локальный веб-сервер и MySQL.

### Команды/код
1. Откройте **XAMPP Control Panel**.
2. Нажмите **Start** у `Apache`.
3. Нажмите **Start** у `MySQL`.
4. Откройте phpMyAdmin:

```text
http://localhost/phpmyadmin
```

---

## Шаг 3. Создайте виртуальное окружение Python
### Что делаем
В терминале VS Code создайте окружение и установите зависимости.

### Команды/код
```cmd
python -m venv .venv
.\.venv\Scripts\activate
pip install -r requirements.txt
```

Если работа идет на macOS:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

---

## Шаг 4. Создайте `requirements.txt`
### Что делаем
Файл содержит библиотеки, которые нужны приложению.

### Команды/код
Создайте файл `requirements.txt` и вставьте код:


```txt
PyQt6==6.7.1
mysql-connector-python==9.0.0
openpyxl==3.1.5
Pillow==10.4.0
pyinstaller==6.10.0

```

---

## Шаг 5. Создайте `db.py`
### Что делаем
Файл отвечает за подключение к MySQL из XAMPP. Для стандартного XAMPP используется пользователь `root` и пустой пароль.

### Команды/код
Создайте файл `db.py` и вставьте код:


```python
import mysql.connector


DB_CONFIG = {
    "host": "127.0.0.1",
    "port": 3306,
    "user": "root",
    "password": "",
    "database": "chitaigorod_demo",
    "use_unicode": True,
    "charset": "utf8mb4",
    "use_pure": True,
}


def get_connection():
    return mysql.connector.connect(**DB_CONFIG)

```

Если в XAMPP у пользователя `root` стоит пароль, измените строку `"password": ""`.

---

## Шаг 6. Создайте `database.sql`
### Что делаем
Файл создает базу данных и таблицы в 3НФ: роли, пользователей, справочники, товары, заказы и состав заказов.

### Команды/код
Создайте файл `database.sql` и вставьте код:


```sql
CREATE DATABASE IF NOT EXISTS chitaigorod_demo
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE chitaigorod_demo;

SET NAMES utf8mb4;

DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS pickup_points;
DROP TABLE IF EXISTS suppliers;
DROP TABLE IF EXISTS manufacturers;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS roles;
DROP TABLE IF EXISTS order_statuses;

CREATE TABLE roles (
    role_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(80) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    role_id INT NOT NULL,
    full_name VARCHAR(180) NOT NULL,
    login VARCHAR(120) NOT NULL UNIQUE,
    password VARCHAR(80) NOT NULL,
    CONSTRAINT fk_users_role
        FOREIGN KEY (role_id) REFERENCES roles(role_id)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE suppliers (
    supplier_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(180) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE manufacturers (
    manufacturer_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(180) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE products (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    article VARCHAR(30) NOT NULL UNIQUE,
    name VARCHAR(255) NOT NULL,
    unit_name VARCHAR(30) NOT NULL,
    price DECIMAL(12,2) NOT NULL CHECK (price >= 0),
    supplier_id INT NOT NULL,
    manufacturer_id INT NOT NULL,
    category_id INT NOT NULL,
    discount_percent DECIMAL(5,2) NOT NULL DEFAULT 0 CHECK (discount_percent >= 0),
    stock_quantity INT NOT NULL DEFAULT 0 CHECK (stock_quantity >= 0),
    description TEXT NULL,
    image_path VARCHAR(255) NULL,
    CONSTRAINT fk_products_supplier
        FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_products_manufacturer
        FOREIGN KEY (manufacturer_id) REFERENCES manufacturers(manufacturer_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_products_category
        FOREIGN KEY (category_id) REFERENCES categories(category_id)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE pickup_points (
    pickup_point_id INT AUTO_INCREMENT PRIMARY KEY,
    address VARCHAR(255) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE order_statuses (
    status_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(80) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE orders (
    order_id INT PRIMARY KEY,
    order_date DATE NULL,
    delivery_date DATE NULL,
    pickup_point_id INT NOT NULL,
    client_name VARCHAR(180) NOT NULL,
    receive_code VARCHAR(20) NOT NULL,
    status_id INT NOT NULL,
    CONSTRAINT fk_orders_pickup
        FOREIGN KEY (pickup_point_id) REFERENCES pickup_points(pickup_point_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_orders_status
        FOREIGN KEY (status_id) REFERENCES order_statuses(status_id)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE order_items (
    order_item_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0),
    CONSTRAINT fk_order_items_order
        FOREIGN KEY (order_id) REFERENCES orders(order_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_order_items_product
        FOREIGN KEY (product_id) REFERENCES products(product_id)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX idx_products_category ON products(category_id);
CREATE INDEX idx_products_supplier ON products(supplier_id);
CREATE INDEX idx_products_manufacturer ON products(manufacturer_id);
CREATE INDEX idx_orders_status ON orders(status_id);

```

---

## Шаг 7. Выполните SQL-скрипт в phpMyAdmin
### Что делаем
Создайте структуру базы данных.

### Команды/код
1. Откройте `http://localhost/phpmyadmin`.
2. Перейдите во вкладку **SQL**.
3. Вставьте весь код из `database.sql`.
4. Нажмите **Вперед** / **Go**.

После выполнения должна появиться база `chitaigorod_demo` и таблицы:
- `roles`;
- `users`;
- `categories`;
- `suppliers`;
- `manufacturers`;
- `products`;
- `pickup_points`;
- `order_statuses`;
- `orders`;
- `order_items`.

---

## Шаг 8. Создайте `check_db.py`
### Что делаем
Файл проверяет, что Python подключается к MySQL.

### Команды/код
Создайте файл `check_db.py` и вставьте код:


```python
from db import get_connection


def main():
    conn = None
    cur = None
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT 1")
        result = cur.fetchone()
        print(f"OK: подключение успешно, SELECT 1 -> {result[0]}")
    except Exception as exc:
        print("ERROR:", exc)
    finally:
        if cur is not None:
            cur.close()
        if conn is not None and conn.is_connected():
            conn.close()


if __name__ == "__main__":
    main()

```

Запуск проверки:

```cmd
python check_db.py
```

Ожидаемый результат:

```text
OK: подключение успешно, SELECT 1 -> 1
```

---

## Шаг 9. Создайте `import_data.py`
### Что делаем
Файл импортирует данные из Excel-файлов в MySQL. Он заполняет пользователей, роли, товары, справочники, пункты выдачи, заказы и состав заказов.

### Команды/код
Создайте файл `import_data.py` и вставьте код:


```python
from datetime import datetime
from decimal import Decimal
from pathlib import Path

from openpyxl import load_workbook

from db import get_connection


BASE_DIR = Path(__file__).resolve().parent
RESOURCES_DIR = BASE_DIR / "resources"


def clean(value):
    if value is None:
        return ""
    return str(value).strip()


def parse_decimal(value):
    if value in (None, ""):
        return Decimal("0")
    return Decimal(str(value).replace(",", ".").strip())


def parse_int(value, default=0):
    if value in (None, ""):
        return default
    return int(float(str(value).replace(",", ".").strip()))


def parse_date(value):
    if value in (None, ""):
        return None
    if hasattr(value, "date"):
        return value.date()

    text = str(value).strip()
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%d.%m.%Y"):
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            pass
    return None


def rows_from_xlsx(path):
    workbook = load_workbook(path, data_only=True)
    sheet = workbook.active
    headers = [clean(cell.value) for cell in sheet[1]]
    for row in sheet.iter_rows(min_row=2, values_only=True):
        if not any(value is not None for value in row):
            continue
        yield dict(zip(headers, row))


def get_or_create(cur, table, column, value):
    id_columns = {
        "categories": "category_id",
        "suppliers": "supplier_id",
        "manufacturers": "manufacturer_id",
    }
    value = clean(value)
    id_column = id_columns[table]
    cur.execute(f"SELECT {id_column} FROM {table} WHERE {column} = %s", (value,))
    row = cur.fetchone()
    if row:
        return row[0]
    cur.execute(f"INSERT INTO {table} ({column}) VALUES (%s)", (value,))
    return cur.lastrowid


def get_or_create_role(cur, name):
    cur.execute("SELECT role_id FROM roles WHERE name = %s", (name,))
    row = cur.fetchone()
    if row:
        return row[0]
    cur.execute("INSERT INTO roles (name) VALUES (%s)", (name,))
    return cur.lastrowid


def get_or_create_status(cur, name):
    cur.execute("SELECT status_id FROM order_statuses WHERE name = %s", (name,))
    row = cur.fetchone()
    if row:
        return row[0]
    cur.execute("INSERT INTO order_statuses (name) VALUES (%s)", (name,))
    return cur.lastrowid


def import_users(cur):
    for row in rows_from_xlsx(RESOURCES_DIR / "user_import.xlsx"):
        role_id = get_or_create_role(cur, clean(row["Роль сотрудника"]))
        cur.execute(
            """
            INSERT INTO users (role_id, full_name, login, password)
            VALUES (%s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                role_id = VALUES(role_id),
                full_name = VALUES(full_name),
                password = VALUES(password)
            """,
            (role_id, clean(row["ФИО"]), clean(row["Логин"]), clean(row["Пароль"])),
        )


def import_products(cur):
    for row in rows_from_xlsx(RESOURCES_DIR / "Tovar.xlsx"):
        supplier_id = get_or_create(cur, "suppliers", "name", row["Поставщик"])
        manufacturer_id = get_or_create(cur, "manufacturers", "name", row["Производитель"])
        category_id = get_or_create(cur, "categories", "name", row["Категория товара"])
        cur.execute(
            """
            INSERT INTO products (
                article, name, unit_name, price, supplier_id, manufacturer_id,
                category_id, discount_percent, stock_quantity, description, image_path
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                name = VALUES(name),
                unit_name = VALUES(unit_name),
                price = VALUES(price),
                supplier_id = VALUES(supplier_id),
                manufacturer_id = VALUES(manufacturer_id),
                category_id = VALUES(category_id),
                discount_percent = VALUES(discount_percent),
                stock_quantity = VALUES(stock_quantity),
                description = VALUES(description),
                image_path = VALUES(image_path)
            """,
            (
                clean(row["Артикул"]),
                clean(row["Наименование товара"]),
                clean(row["Единица измерения"]),
                parse_decimal(row["Цена"]),
                supplier_id,
                manufacturer_id,
                category_id,
                parse_decimal(row["Действующая скидка"]),
                parse_int(row["Кол-во на складе"]),
                clean(row["Описание товара"]),
                clean(row["Фото"]) or "picture.png",
            ),
        )


def import_pickup_points(cur):
    for row in rows_from_xlsx(RESOURCES_DIR / "Пункты выдачи_import.xlsx"):
        address = clean(next(iter(row.values())))
        if address:
            cur.execute(
                """
                INSERT INTO pickup_points (address)
                VALUES (%s)
                ON DUPLICATE KEY UPDATE address = VALUES(address)
                """,
                (address,),
            )


def parse_order_items(raw):
    parts = [part.strip() for part in clean(raw).split(",")]
    items = []
    for index in range(0, len(parts), 2):
        if index + 1 >= len(parts):
            continue
        article = parts[index]
        quantity = parse_int(parts[index + 1], default=1)
        if article and quantity > 0:
            items.append((article, quantity))
    return items


def import_orders(cur):
    for row in rows_from_xlsx(RESOURCES_DIR / "Заказ_import.xlsx"):
        order_id = parse_int(row["Номер заказа"])
        status_id = get_or_create_status(cur, clean(row["Статус заказа"]) or "Новый")
        pickup_point_id = parse_int(row["Адрес пункта выдачи"])
        cur.execute(
            """
            INSERT INTO orders (
                order_id, order_date, delivery_date, pickup_point_id,
                client_name, receive_code, status_id
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                order_date = VALUES(order_date),
                delivery_date = VALUES(delivery_date),
                pickup_point_id = VALUES(pickup_point_id),
                client_name = VALUES(client_name),
                receive_code = VALUES(receive_code),
                status_id = VALUES(status_id)
            """,
            (
                order_id,
                parse_date(row["Дата заказа"]),
                parse_date(row["Дата доставки"]),
                pickup_point_id,
                clean(row["ФИО авторизированного клиента"]),
                clean(row["Код для получения"]),
                status_id,
            ),
        )
        cur.execute("DELETE FROM order_items WHERE order_id = %s", (order_id,))
        for article, quantity in parse_order_items(row["Артикул заказа"]):
            cur.execute("SELECT product_id FROM products WHERE article = %s", (article,))
            product = cur.fetchone()
            if product is None:
                continue
            cur.execute(
                "INSERT INTO order_items (order_id, product_id, quantity) VALUES (%s, %s, %s)",
                (order_id, product[0], quantity),
            )


def main():
    conn = get_connection()
    try:
        cur = conn.cursor()
        import_users(cur)
        import_products(cur)
        import_pickup_points(cur)
        import_orders(cur)
        conn.commit()
        print("OK: данные импортированы")
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


if __name__ == "__main__":
    main()

```

Запуск импорта:

```cmd
python import_data.py
```

Ожидаемый результат:

```text
OK: данные импортированы
```

---

## Шаг 10. Создайте `main.py`
### Что делаем
Файл содержит все окна приложения: авторизацию, список товаров, форму товара, список заказов и форму заказа.

### Команды/код
Создайте файл `main.py` и вставьте код:


```python
import sys
import time
from decimal import Decimal, InvalidOperation
from pathlib import Path

from PIL import Image
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QIcon, QPixmap
from PyQt6.QtWidgets import (
    QApplication,
    QComboBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from db import get_connection


BASE_DIR = Path(__file__).resolve().parent
RESOURCES_DIR = BASE_DIR / "resources"
CUSTOM_IMAGES_DIR = RESOURCES_DIR / "custom_images"
LOGO_PATH = RESOURCES_DIR / "icon.png"
ICON_PATH = RESOURCES_DIR / "icon.ico"
PLACEHOLDER_PATH = RESOURCES_DIR / "picture.png"

COLOR_MAIN_BG = "#FFFFFF"
COLOR_SECOND_BG = "#ABCFCE"
COLOR_ACCENT = "#546F94"
COLOR_DISCOUNT = "#23E1EF"
COLOR_EMPTY_STOCK = "#D9D9D9"

ROLE_ADMIN = "Администратор"
ROLE_MANAGER = "Менеджер"
ROLE_CLIENT = "Авторизированный клиент"
ROLE_GUEST = "Гость"


def money(value):
    return Decimal(str(value or 0)).quantize(Decimal("0.01"))


def final_price(price, discount):
    return money(price) * (Decimal("1") - Decimal(str(discount or 0)) / Decimal("100"))


def parse_decimal(text, field_name):
    try:
        value = Decimal(text.replace(",", ".").strip())
    except (InvalidOperation, AttributeError):
        raise ValueError(f"Поле '{field_name}' должно быть числом.")
    if value < 0:
        raise ValueError(f"Поле '{field_name}' не может быть отрицательным.")
    return value


def parse_int(text, field_name):
    try:
        value = int(text.strip())
    except (ValueError, AttributeError):
        raise ValueError(f"Поле '{field_name}' должно быть целым числом.")
    if value < 0:
        raise ValueError(f"Поле '{field_name}' не может быть отрицательным.")
    return value


def run_query(sql, params=(), fetch=False, dictionary=True):
    conn = get_connection()
    try:
        cur = conn.cursor(dictionary=dictionary)
        cur.execute(sql, params)
        if fetch:
            return cur.fetchall()
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def load_lookup(table, id_column):
    return run_query(f"SELECT {id_column} AS id, name FROM {table} ORDER BY name", fetch=True)


def image_path(name):
    if not name:
        return PLACEHOLDER_PATH
    path = RESOURCES_DIR / name
    if path.exists():
        return path
    path = BASE_DIR / name
    if path.exists():
        return path
    return PLACEHOLDER_PATH


class BaseWindow(QMainWindow):
    def apply_base_style(self):
        self.setStyleSheet(
            f"""
            QMainWindow, QDialog, QWidget {{
                background-color: {COLOR_MAIN_BG};
                font-family: "Comic Sans MS";
                font-size: 12px;
            }}
            QLineEdit, QTextEdit, QComboBox {{
                border: 1px solid #888888;
                border-radius: 4px;
                padding: 6px;
                background: white;
            }}
            QPushButton {{
                background-color: {COLOR_ACCENT};
                color: white;
                border: none;
                border-radius: 4px;
                padding: 7px 12px;
            }}
            QPushButton:disabled {{
                background-color: #999999;
            }}
            QTableWidget {{
                gridline-color: #888888;
                selection-background-color: {COLOR_ACCENT};
                selection-color: white;
            }}
            """
        )


class LoginWindow(BaseWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ЧитайГород - вход")
        self.setWindowIcon(QIcon(str(ICON_PATH)))
        self.apply_base_style()
        self.resize(520, 360)

        root = QWidget()
        layout = QVBoxLayout(root)
        layout.setContentsMargins(32, 28, 32, 28)
        layout.setSpacing(14)

        logo = QLabel()
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        if LOGO_PATH.exists():
            logo.setPixmap(QPixmap(str(LOGO_PATH)).scaled(96, 96, Qt.AspectRatioMode.KeepAspectRatio))
        layout.addWidget(logo)

        title = QLabel("ООО «ЧитайГород»")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title_font = QFont("Comic Sans MS", 18, QFont.Weight.Bold)
        title.setFont(title_font)
        layout.addWidget(title)

        self.login_edit = QLineEdit()
        self.login_edit.setPlaceholderText("Логин")
        self.password_edit = QLineEdit()
        self.password_edit.setPlaceholderText("Пароль")
        self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        layout.addWidget(self.login_edit)
        layout.addWidget(self.password_edit)

        buttons = QHBoxLayout()
        enter_button = QPushButton("Войти")
        guest_button = QPushButton("Войти как гость")
        enter_button.clicked.connect(self.authorize)
        guest_button.clicked.connect(self.open_guest)
        buttons.addWidget(enter_button)
        buttons.addWidget(guest_button)
        layout.addLayout(buttons)

        self.setCentralWidget(root)

    def authorize(self):
        login = self.login_edit.text().strip()
        password = self.password_edit.text().strip()
        if not login or not password:
            QMessageBox.warning(self, "Ошибка входа", "Введите логин и пароль.")
            return
        rows = run_query(
            """
            SELECT u.user_id, u.full_name, r.name AS role_name
            FROM users u
            JOIN roles r ON r.role_id = u.role_id
            WHERE u.login = %s AND u.password = %s
            """,
            (login, password),
            fetch=True,
        )
        if not rows:
            QMessageBox.critical(self, "Ошибка входа", "Пользователь с такими данными не найден.")
            return
        self.open_products(rows[0]["role_name"], rows[0]["full_name"])

    def open_guest(self):
        self.open_products(ROLE_GUEST, "Гость")

    def open_products(self, role, full_name):
        self.products_window = ProductsWindow(role, full_name, self)
        self.products_window.show()
        self.hide()


class ProductsWindow(BaseWindow):
    def __init__(self, role, full_name, login_window):
        super().__init__()
        self.role = role
        self.full_name = full_name
        self.login_window = login_window
        self.edit_dialog_open = False
        self.setWindowTitle("ЧитайГород - товары")
        self.setWindowIcon(QIcon(str(ICON_PATH)))
        self.apply_base_style()
        self.resize(1320, 760)

        root = QWidget()
        layout = QVBoxLayout(root)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(10)

        header = QHBoxLayout()
        logo = QLabel()
        if LOGO_PATH.exists():
            logo.setPixmap(QPixmap(str(LOGO_PATH)).scaled(52, 52, Qt.AspectRatioMode.KeepAspectRatio))
        header.addWidget(logo)
        title = QLabel("Список товаров")
        title.setFont(QFont("Comic Sans MS", 18, QFont.Weight.Bold))
        header.addWidget(title)
        header.addStretch()
        header.addWidget(QLabel(f"{self.full_name}"))
        logout_button = QPushButton("Выйти")
        logout_button.clicked.connect(self.logout)
        header.addWidget(logout_button)
        layout.addLayout(header)

        self.controls = QHBoxLayout()
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Поиск")
        self.sort_combo = QComboBox()
        self.sort_combo.addItems([
            "Без сортировки",
            "Цена по возрастанию",
            "Цена по убыванию",
            "Остаток по возрастанию",
            "Остаток по убыванию",
        ])
        self.discount_combo = QComboBox()
        self.discount_combo.addItems(["Все диапазоны", "0-12,99%", "13-16,99%", "17% и более"])
        self.add_button = QPushButton("Добавить товар")
        self.delete_button = QPushButton("Удалить товар")
        self.orders_button = QPushButton("Заказы")

        self.search_edit.textChanged.connect(self.load_products)
        self.sort_combo.currentIndexChanged.connect(self.load_products)
        self.discount_combo.currentIndexChanged.connect(self.load_products)
        self.add_button.clicked.connect(self.add_product)
        self.delete_button.clicked.connect(self.delete_product)
        self.orders_button.clicked.connect(self.open_orders)

        if self.role in (ROLE_MANAGER, ROLE_ADMIN):
            self.controls.addWidget(self.search_edit, 2)
            self.controls.addWidget(self.sort_combo, 1)
            self.controls.addWidget(self.discount_combo, 1)
            self.controls.addWidget(self.orders_button)
        if self.role == ROLE_ADMIN:
            self.controls.addWidget(self.add_button)
            self.controls.addWidget(self.delete_button)
        if self.role in (ROLE_MANAGER, ROLE_ADMIN):
            layout.addLayout(self.controls)

        self.table = QTableWidget()
        self.table.setColumnCount(11)
        self.table.setHorizontalHeaderLabels([
            "Фото",
            "Артикул",
            "Наименование",
            "Категория",
            "Описание",
            "Производитель",
            "Поставщик",
            "Цена",
            "Ед.",
            "Остаток",
            "Скидка",
        ])
        self.table.verticalHeader().setDefaultSectionSize(82)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.doubleClicked.connect(self.edit_selected_product)
        layout.addWidget(self.table)

        self.setCentralWidget(root)
        self.load_products()

    def logout(self):
        self.login_window.show()
        self.close()

    def build_filter(self):
        where = []
        params = []
        if self.role in (ROLE_MANAGER, ROLE_ADMIN):
            search = self.search_edit.text().strip()
            if search:
                like = f"%{search}%"
                where.append(
                    """
                    (p.article LIKE %s OR p.name LIKE %s OR p.description LIKE %s
                     OR c.name LIKE %s OR s.name LIKE %s OR m.name LIKE %s OR p.unit_name LIKE %s)
                    """
                )
                params.extend([like] * 7)
            discount_index = self.discount_combo.currentIndex()
            if discount_index == 1:
                where.append("p.discount_percent >= 0 AND p.discount_percent < 13")
            elif discount_index == 2:
                where.append("p.discount_percent >= 13 AND p.discount_percent < 17")
            elif discount_index == 3:
                where.append("p.discount_percent >= 17")

        clause = "WHERE " + " AND ".join(where) if where else ""
        order_by = "ORDER BY p.product_id"
        if self.role in (ROLE_MANAGER, ROLE_ADMIN):
            sort_index = self.sort_combo.currentIndex()
            order_by = {
                1: "ORDER BY p.price ASC, p.name",
                2: "ORDER BY p.price DESC, p.name",
                3: "ORDER BY p.stock_quantity ASC, p.name",
                4: "ORDER BY p.stock_quantity DESC, p.name",
            }.get(sort_index, order_by)
        return clause, params, order_by

    def load_products(self):
        clause, params, order_by = self.build_filter()
        rows = run_query(
            f"""
            SELECT
                p.product_id, p.article, p.name, p.unit_name, p.price,
                p.discount_percent, p.stock_quantity, p.description, p.image_path,
                c.name AS category_name,
                s.name AS supplier_name,
                m.name AS manufacturer_name
            FROM products p
            JOIN categories c ON c.category_id = p.category_id
            JOIN suppliers s ON s.supplier_id = p.supplier_id
            JOIN manufacturers m ON m.manufacturer_id = p.manufacturer_id
            {clause}
            {order_by}
            """,
            tuple(params),
            fetch=True,
        )
        self.table.setRowCount(len(rows))
        for row_index, row in enumerate(rows):
            self.table.setRowHeight(row_index, 82)
            self.table.setVerticalHeaderItem(row_index, QTableWidgetItem(str(row["product_id"])))
            self.fill_product_row(row_index, row)
        self.table.resizeColumnsToContents()
        self.table.setColumnWidth(2, 250)
        self.table.setColumnWidth(4, 330)

    def row_color(self, row):
        if int(row["stock_quantity"]) == 0:
            return QColor(COLOR_EMPTY_STOCK)
        if Decimal(str(row["discount_percent"])) > Decimal("25"):
            return QColor(COLOR_DISCOUNT)
        return QColor(COLOR_MAIN_BG)

    def fill_product_row(self, row_index, row):
        bg_color = self.row_color(row)

        photo = QLabel()
        photo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        photo.setPixmap(QPixmap(str(image_path(row["image_path"]))).scaled(56, 76, Qt.AspectRatioMode.KeepAspectRatio))
        photo.setStyleSheet(f"background-color: {bg_color.name()};")
        self.table.setCellWidget(row_index, 0, photo)

        values = [
            row["article"],
            row["name"],
            row["category_name"],
            row["description"] or "",
            row["manufacturer_name"],
            row["supplier_name"],
            "",
            row["unit_name"],
            str(row["stock_quantity"]),
            f"{money(row['discount_percent'])}%",
        ]
        for column, value in enumerate(values, start=1):
            item = QTableWidgetItem(str(value))
            item.setBackground(bg_color)
            item.setData(Qt.ItemDataRole.UserRole, row["product_id"])
            self.table.setItem(row_index, column, item)

        price_label = QLabel()
        price_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        price = money(row["price"])
        discount = money(row["discount_percent"])
        if discount > 0:
            result = final_price(price, discount).quantize(Decimal("0.01"))
            price_label.setText(f"<span style='color:red;text-decoration:line-through'>{price}</span><br><span style='color:black'>{result}</span>")
        else:
            price_label.setText(str(price))
        price_label.setStyleSheet(f"background-color: {bg_color.name()};")
        self.table.setCellWidget(row_index, 7, price_label)

    def selected_product_id(self):
        row = self.table.currentRow()
        if row < 0:
            return None
        item = self.table.item(row, 1)
        return item.data(Qt.ItemDataRole.UserRole) if item else None

    def add_product(self):
        self.open_product_dialog(None)

    def edit_selected_product(self):
        if self.role != ROLE_ADMIN:
            return
        product_id = self.selected_product_id()
        if product_id:
            self.open_product_dialog(product_id)

    def open_product_dialog(self, product_id):
        if self.edit_dialog_open:
            QMessageBox.warning(self, "Редактирование товара", "Сейчас уже открыта форма товара.")
            return
        self.edit_dialog_open = True
        self.product_dialog = ProductDialog(self, product_id)
        self.product_dialog.finished.connect(lambda _: self._product_dialog_closed())
        self.product_dialog.saved.connect(self.load_products)
        self.product_dialog.show()

    def _product_dialog_closed(self):
        self.edit_dialog_open = False
        self.product_dialog = None

    def delete_product(self):
        product_id = self.selected_product_id()
        if not product_id:
            QMessageBox.warning(self, "Удаление товара", "Выберите товар для удаления.")
            return
        rows = run_query("SELECT COUNT(*) AS cnt FROM order_items WHERE product_id = %s", (product_id,), fetch=True)
        if rows[0]["cnt"] > 0:
            QMessageBox.critical(self, "Удаление товара", "Товар присутствует в заказе, поэтому удалить его нельзя.")
            return
        answer = QMessageBox.question(self, "Удаление товара", "Удалить выбранный товар?")
        if answer != QMessageBox.StandardButton.Yes:
            return
        run_query("DELETE FROM products WHERE product_id = %s", (product_id,), dictionary=False)
        self.load_products()

    def open_orders(self):
        self.orders_window = OrdersWindow(self.role, self.full_name, self)
        self.orders_window.show()


class ProductDialog(QDialog):
    saved = pyqtSignal()

    def __init__(self, parent, product_id=None):
        super().__init__(parent)
        self.product_id = product_id
        self.current_image = ""
        self.new_image_source = None
        self.setWindowTitle("Редактирование товара" if product_id else "Добавление товара")
        self.setWindowIcon(QIcon(str(ICON_PATH)))
        self.setModal(False)
        self.resize(620, 640)

        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.id_label = QLabel("Автоматически")
        self.article_edit = QLineEdit()
        self.name_edit = QLineEdit()
        self.unit_edit = QLineEdit()
        self.price_edit = QLineEdit()
        self.category_combo = QComboBox()
        self.supplier_combo = QComboBox()
        self.manufacturer_combo = QComboBox()
        self.stock_edit = QLineEdit()
        self.discount_edit = QLineEdit()
        self.description_edit = QTextEdit()
        self.image_label = QLabel("picture.png")
        self.image_label.setWordWrap(True)
        image_button = QPushButton("Выбрать изображение")
        image_button.clicked.connect(self.choose_image)

        self.fill_combo(self.category_combo, "categories", "category_id")
        self.fill_combo(self.supplier_combo, "suppliers", "supplier_id")
        self.fill_combo(self.manufacturer_combo, "manufacturers", "manufacturer_id")

        form.addRow("ID товара", self.id_label)
        form.addRow("Артикул", self.article_edit)
        form.addRow("Наименование", self.name_edit)
        form.addRow("Категория", self.category_combo)
        form.addRow("Описание", self.description_edit)
        form.addRow("Производитель", self.manufacturer_combo)
        form.addRow("Поставщик", self.supplier_combo)
        form.addRow("Цена", self.price_edit)
        form.addRow("Единица измерения", self.unit_edit)
        form.addRow("Количество на складе", self.stock_edit)
        form.addRow("Действующая скидка", self.discount_edit)
        form.addRow("Фото", self.image_label)
        form.addRow("", image_button)
        layout.addLayout(form)

        buttons = QHBoxLayout()
        save_button = QPushButton("Сохранить")
        cancel_button = QPushButton("Назад")
        save_button.clicked.connect(self.save)
        cancel_button.clicked.connect(self.close)
        buttons.addStretch()
        buttons.addWidget(save_button)
        buttons.addWidget(cancel_button)
        layout.addLayout(buttons)

        if product_id:
            self.load_product()

    def fill_combo(self, combo, table, id_column):
        combo.clear()
        for row in load_lookup(table, id_column):
            combo.addItem(row["name"], row["id"])

    def set_combo_value(self, combo, value):
        index = combo.findData(value)
        if index >= 0:
            combo.setCurrentIndex(index)

    def load_product(self):
        rows = run_query(
            "SELECT * FROM products WHERE product_id = %s",
            (self.product_id,),
            fetch=True,
        )
        if not rows:
            QMessageBox.critical(self, "Ошибка", "Товар не найден.")
            self.close()
            return
        row = rows[0]
        self.id_label.setText(str(row["product_id"]))
        self.article_edit.setText(row["article"])
        self.name_edit.setText(row["name"])
        self.unit_edit.setText(row["unit_name"])
        self.price_edit.setText(str(money(row["price"])))
        self.stock_edit.setText(str(row["stock_quantity"]))
        self.discount_edit.setText(str(money(row["discount_percent"])))
        self.description_edit.setPlainText(row["description"] or "")
        self.current_image = row["image_path"] or "picture.png"
        self.image_label.setText(self.current_image)
        self.set_combo_value(self.category_combo, row["category_id"])
        self.set_combo_value(self.supplier_combo, row["supplier_id"])
        self.set_combo_value(self.manufacturer_combo, row["manufacturer_id"])

    def choose_image(self):
        path, _ = QFileDialog.getOpenFileName(self, "Выберите изображение", "", "Images (*.png *.jpg *.jpeg)")
        if not path:
            return
        self.new_image_source = Path(path)
        self.image_label.setText(self.new_image_source.name)

    def save_image(self):
        if self.new_image_source is None:
            return self.current_image or "picture.png"
        CUSTOM_IMAGES_DIR.mkdir(exist_ok=True)
        suffix = self.new_image_source.suffix.lower()
        target_name = f"product_{int(time.time())}{suffix}"
        target_path = CUSTOM_IMAGES_DIR / target_name
        with Image.open(self.new_image_source) as img:
            img.thumbnail((300, 200))
            img.save(target_path)
        if self.current_image.startswith("custom_images/"):
            old_path = RESOURCES_DIR / self.current_image
            if old_path.exists():
                old_path.unlink()
        return f"custom_images/{target_name}"

    def validate(self):
        data = {
            "article": self.article_edit.text().strip(),
            "name": self.name_edit.text().strip(),
            "unit_name": self.unit_edit.text().strip(),
            "price": parse_decimal(self.price_edit.text(), "Цена"),
            "category_id": self.category_combo.currentData(),
            "supplier_id": self.supplier_combo.currentData(),
            "manufacturer_id": self.manufacturer_combo.currentData(),
            "stock_quantity": parse_int(self.stock_edit.text(), "Количество на складе"),
            "discount_percent": parse_decimal(self.discount_edit.text(), "Действующая скидка"),
            "description": self.description_edit.toPlainText().strip(),
        }
        required = ["article", "name", "unit_name"]
        for field in required:
            if not data[field]:
                raise ValueError("Заполните артикул, наименование и единицу измерения.")
        return data

    def save(self):
        try:
            data = self.validate()
            data["image_path"] = self.save_image()
            if self.product_id:
                run_query(
                    """
                    UPDATE products
                    SET article=%s, name=%s, unit_name=%s, price=%s, supplier_id=%s,
                        manufacturer_id=%s, category_id=%s, discount_percent=%s,
                        stock_quantity=%s, description=%s, image_path=%s
                    WHERE product_id=%s
                    """,
                    (
                        data["article"],
                        data["name"],
                        data["unit_name"],
                        data["price"],
                        data["supplier_id"],
                        data["manufacturer_id"],
                        data["category_id"],
                        data["discount_percent"],
                        data["stock_quantity"],
                        data["description"],
                        data["image_path"],
                        self.product_id,
                    ),
                    dictionary=False,
                )
            else:
                run_query(
                    """
                    INSERT INTO products (
                        article, name, unit_name, price, supplier_id, manufacturer_id,
                        category_id, discount_percent, stock_quantity, description, image_path
                    )
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """,
                    (
                        data["article"],
                        data["name"],
                        data["unit_name"],
                        data["price"],
                        data["supplier_id"],
                        data["manufacturer_id"],
                        data["category_id"],
                        data["discount_percent"],
                        data["stock_quantity"],
                        data["description"],
                        data["image_path"],
                    ),
                    dictionary=False,
                )
            self.saved.emit()
            self.close()
        except Exception as exc:
            QMessageBox.critical(self, "Ошибка сохранения", str(exc))


class OrdersWindow(BaseWindow):
    def __init__(self, role, full_name, products_window):
        super().__init__()
        self.role = role
        self.full_name = full_name
        self.products_window = products_window
        self.setWindowTitle("ЧитайГород - заказы")
        self.setWindowIcon(QIcon(str(ICON_PATH)))
        self.apply_base_style()
        self.resize(1120, 620)

        root = QWidget()
        layout = QVBoxLayout(root)
        header = QHBoxLayout()
        title = QLabel("Заказы")
        title.setFont(QFont("Comic Sans MS", 18, QFont.Weight.Bold))
        header.addWidget(title)
        header.addStretch()
        header.addWidget(QLabel(self.full_name))
        back_button = QPushButton("Назад")
        back_button.clicked.connect(self.close)
        header.addWidget(back_button)
        layout.addLayout(header)

        if self.role == ROLE_ADMIN:
            actions = QHBoxLayout()
            add_button = QPushButton("Добавить заказ")
            edit_button = QPushButton("Редактировать заказ")
            delete_button = QPushButton("Удалить заказ")
            add_button.clicked.connect(lambda: self.open_order_dialog(None))
            edit_button.clicked.connect(self.edit_order)
            delete_button.clicked.connect(self.delete_order)
            actions.addWidget(add_button)
            actions.addWidget(edit_button)
            actions.addWidget(delete_button)
            actions.addStretch()
            layout.addLayout(actions)

        self.table = QTableWidget()
        self.table.setColumnCount(8)
        self.table.setHorizontalHeaderLabels([
            "Номер",
            "Артикулы",
            "Дата заказа",
            "Дата выдачи",
            "Пункт выдачи",
            "Клиент",
            "Код",
            "Статус",
        ])
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.doubleClicked.connect(self.edit_order)
        layout.addWidget(self.table)
        self.setCentralWidget(root)
        self.load_orders()

    def load_orders(self):
        rows = run_query(
            """
            SELECT
                o.order_id,
                o.order_date,
                o.delivery_date,
                pp.address,
                o.client_name,
                o.receive_code,
                os.name AS status_name,
                GROUP_CONCAT(CONCAT(p.article, ', ', oi.quantity) ORDER BY p.article SEPARATOR ', ') AS items
            FROM orders o
            JOIN pickup_points pp ON pp.pickup_point_id = o.pickup_point_id
            JOIN order_statuses os ON os.status_id = o.status_id
            LEFT JOIN order_items oi ON oi.order_id = o.order_id
            LEFT JOIN products p ON p.product_id = oi.product_id
            GROUP BY o.order_id, o.order_date, o.delivery_date, pp.address, o.client_name, o.receive_code, os.name
            ORDER BY o.order_id
            """,
            fetch=True,
        )
        self.table.setRowCount(len(rows))
        for row_index, row in enumerate(rows):
            values = [
                row["order_id"],
                row["items"] or "",
                row["order_date"] or "",
                row["delivery_date"] or "",
                row["address"],
                row["client_name"],
                row["receive_code"],
                row["status_name"],
            ]
            for column, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setData(Qt.ItemDataRole.UserRole, row["order_id"])
                self.table.setItem(row_index, column, item)
        self.table.resizeColumnsToContents()
        self.table.setColumnWidth(1, 260)
        self.table.setColumnWidth(4, 280)

    def selected_order_id(self):
        row = self.table.currentRow()
        if row < 0:
            return None
        item = self.table.item(row, 0)
        return item.data(Qt.ItemDataRole.UserRole) if item else None

    def edit_order(self):
        if self.role != ROLE_ADMIN:
            return
        order_id = self.selected_order_id()
        if order_id:
            self.open_order_dialog(order_id)

    def open_order_dialog(self, order_id):
        dialog = OrderDialog(self, order_id)
        dialog.saved.connect(self.load_orders)
        dialog.exec()

    def delete_order(self):
        order_id = self.selected_order_id()
        if not order_id:
            QMessageBox.warning(self, "Удаление заказа", "Выберите заказ для удаления.")
            return
        answer = QMessageBox.question(self, "Удаление заказа", "Удалить выбранный заказ?")
        if answer != QMessageBox.StandardButton.Yes:
            return
        run_query("DELETE FROM orders WHERE order_id = %s", (order_id,), dictionary=False)
        self.load_orders()


class OrderDialog(QDialog):
    saved = pyqtSignal()

    def __init__(self, parent, order_id=None):
        super().__init__(parent)
        self.order_id = order_id
        self.setWindowTitle("Редактирование заказа" if order_id else "Добавление заказа")
        self.setWindowIcon(QIcon(str(ICON_PATH)))
        self.resize(620, 420)

        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.order_id_edit = QLineEdit()
        self.order_id_edit.setReadOnly(True)
        self.items_edit = QLineEdit()
        self.items_edit.setPlaceholderText("А112Т4, 2, G843H5, 1")
        self.status_combo = QComboBox()
        self.pickup_combo = QComboBox()
        self.order_date_edit = QLineEdit()
        self.order_date_edit.setPlaceholderText("YYYY-MM-DD")
        self.delivery_date_edit = QLineEdit()
        self.delivery_date_edit.setPlaceholderText("YYYY-MM-DD")
        self.client_edit = QLineEdit()
        self.code_edit = QLineEdit()

        for row in load_lookup("order_statuses", "status_id"):
            self.status_combo.addItem(row["name"], row["id"])
        pickup_rows = run_query("SELECT pickup_point_id AS id, address AS name FROM pickup_points ORDER BY pickup_point_id", fetch=True)
        for row in pickup_rows:
            self.pickup_combo.addItem(row["name"], row["id"])

        form.addRow("Номер заказа", self.order_id_edit)
        form.addRow("Артикул", self.items_edit)
        form.addRow("Статус заказа", self.status_combo)
        form.addRow("Адрес пункта выдачи", self.pickup_combo)
        form.addRow("Дата заказа", self.order_date_edit)
        form.addRow("Дата выдачи", self.delivery_date_edit)
        form.addRow("ФИО клиента", self.client_edit)
        form.addRow("Код получения", self.code_edit)
        layout.addLayout(form)

        buttons = QHBoxLayout()
        save_button = QPushButton("Сохранить")
        cancel_button = QPushButton("Назад")
        save_button.clicked.connect(self.save)
        cancel_button.clicked.connect(self.close)
        buttons.addStretch()
        buttons.addWidget(save_button)
        buttons.addWidget(cancel_button)
        layout.addLayout(buttons)

        if order_id:
            self.load_order()
        else:
            rows = run_query("SELECT COALESCE(MAX(order_id), 0) + 1 AS next_id FROM orders", fetch=True)
            self.order_id_edit.setText(str(rows[0]["next_id"]))

    def set_combo_value(self, combo, value):
        index = combo.findData(value)
        if index >= 0:
            combo.setCurrentIndex(index)

    def load_order(self):
        rows = run_query("SELECT * FROM orders WHERE order_id = %s", (self.order_id,), fetch=True)
        if not rows:
            QMessageBox.critical(self, "Ошибка", "Заказ не найден.")
            self.close()
            return
        row = rows[0]
        items = run_query(
            """
            SELECT p.article, oi.quantity
            FROM order_items oi
            JOIN products p ON p.product_id = oi.product_id
            WHERE oi.order_id = %s
            ORDER BY oi.order_item_id
            """,
            (self.order_id,),
            fetch=True,
        )
        self.order_id_edit.setText(str(row["order_id"]))
        self.items_edit.setText(", ".join(f"{item['article']}, {item['quantity']}" for item in items))
        self.order_date_edit.setText(str(row["order_date"] or ""))
        self.delivery_date_edit.setText(str(row["delivery_date"] or ""))
        self.client_edit.setText(row["client_name"])
        self.code_edit.setText(row["receive_code"])
        self.set_combo_value(self.status_combo, row["status_id"])
        self.set_combo_value(self.pickup_combo, row["pickup_point_id"])

    def parse_items(self):
        parts = [part.strip() for part in self.items_edit.text().split(",")]
        if len(parts) < 2 or len(parts) % 2 != 0:
            raise ValueError("Введите артикулы в формате: А112Т4, 2, G843H5, 1.")
        result = []
        for index in range(0, len(parts), 2):
            article = parts[index]
            quantity = parse_int(parts[index + 1], "Количество товара в заказе")
            if quantity <= 0:
                raise ValueError("Количество товара в заказе должно быть больше нуля.")
            product = run_query("SELECT product_id FROM products WHERE article = %s", (article,), fetch=True)
            if not product:
                raise ValueError(f"Товар с артикулом '{article}' не найден.")
            result.append((product[0]["product_id"], quantity))
        return result

    def save(self):
        try:
            order_id = parse_int(self.order_id_edit.text(), "Номер заказа")
            items = self.parse_items()
            if not self.client_edit.text().strip() or not self.code_edit.text().strip():
                raise ValueError("Заполните ФИО клиента и код получения.")
            if self.order_id:
                run_query(
                    """
                    UPDATE orders
                    SET order_date=%s, delivery_date=%s, pickup_point_id=%s,
                        client_name=%s, receive_code=%s, status_id=%s
                    WHERE order_id=%s
                    """,
                    (
                        self.order_date_edit.text().strip() or None,
                        self.delivery_date_edit.text().strip() or None,
                        self.pickup_combo.currentData(),
                        self.client_edit.text().strip(),
                        self.code_edit.text().strip(),
                        self.status_combo.currentData(),
                        order_id,
                    ),
                    dictionary=False,
                )
            else:
                run_query(
                    """
                    INSERT INTO orders (
                        order_id, order_date, delivery_date, pickup_point_id,
                        client_name, receive_code, status_id
                    )
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                    """,
                    (
                        order_id,
                        self.order_date_edit.text().strip() or None,
                        self.delivery_date_edit.text().strip() or None,
                        self.pickup_combo.currentData(),
                        self.client_edit.text().strip(),
                        self.code_edit.text().strip(),
                        self.status_combo.currentData(),
                    ),
                    dictionary=False,
                )
            run_query("DELETE FROM order_items WHERE order_id = %s", (order_id,), dictionary=False)
            for product_id, quantity in items:
                run_query(
                    "INSERT INTO order_items (order_id, product_id, quantity) VALUES (%s, %s, %s)",
                    (order_id, product_id, quantity),
                    dictionary=False,
                )
            self.saved.emit()
            self.close()
        except Exception as exc:
            QMessageBox.critical(self, "Ошибка сохранения", str(exc))


def main():
    app = QApplication(sys.argv)
    app.setFont(QFont("Comic Sans MS", 10))
    if ICON_PATH.exists():
        app.setWindowIcon(QIcon(str(ICON_PATH)))
    window = LoginWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()

```

---

## Шаг 11. Создайте `er_diagram.mmd`
### Что делаем
Файл нужен для ER-диаграммы. Его можно открыть в VS Code через Mermaid Preview или перенести в draw.io и экспортировать в PDF.

### Команды/код
Создайте файл `er_diagram.mmd` и вставьте код:


```mermaid
erDiagram
    roles ||--o{ users : has
    categories ||--o{ products : groups
    suppliers ||--o{ products : supplies
    manufacturers ||--o{ products : publishes
    pickup_points ||--o{ orders : receives
    order_statuses ||--o{ orders : marks
    orders ||--o{ order_items : contains
    products ||--o{ order_items : included

    roles {
        int role_id PK
        varchar name
    }

    users {
        int user_id PK
        int role_id FK
        varchar full_name
        varchar login
        varchar password
    }

    categories {
        int category_id PK
        varchar name
    }

    suppliers {
        int supplier_id PK
        varchar name
    }

    manufacturers {
        int manufacturer_id PK
        varchar name
    }

    products {
        int product_id PK
        varchar article
        varchar name
        varchar unit_name
        decimal price
        int supplier_id FK
        int manufacturer_id FK
        int category_id FK
        decimal discount_percent
        int stock_quantity
        text description
        varchar image_path
    }

    pickup_points {
        int pickup_point_id PK
        varchar address
    }

    order_statuses {
        int status_id PK
        varchar name
    }

    orders {
        int order_id PK
        date order_date
        date delivery_date
        int pickup_point_id FK
        varchar client_name
        varchar receive_code
        int status_id FK
    }

    order_items {
        int order_item_id PK
        int order_id FK
        int product_id FK
        int quantity
    }

```

---

## Шаг 12. Запустите приложение
### Что делаем
После создания БД и импорта данных запустите интерфейс.

### Команды/код
```cmd
python main.py
```

Первым откроется окно входа.

---

## Шаг 13. Данные для входа
### Что делаем
Проверьте разные роли пользователей.

### Команды/код
Администратор:

```text
Логин: 94d5ous@gmail.com
Пароль: uzWC67
```

Менеджер:

```text
Логин: ptec8ym@yahoo.com
Пароль: LdNyos
```

Авторизированный клиент:

```text
Логин: yzls62@outlook.com
Пароль: JlFRCZ
```

Также есть кнопка **Войти как гость**.

---

## Шаг 13.1. Если логины и пароли не работают
### Что делаем
Проверьте, что пользователи реально есть в таблице `users`. Приложение проверяет логин и пароль не из инструкции, а из MySQL.

### Команды/код
В phpMyAdmin выполните:

```sql
USE chitaigorod_demo;

SELECT
    u.user_id,
    r.name AS role_name,
    u.full_name,
    u.login,
    u.password
FROM users u
JOIN roles r ON r.role_id = u.role_id
ORDER BY u.user_id;
```

Если таблица пустая, выполните импорт данных в терминале VS Code:

```cmd
.\.venv\Scripts\activate
python import_data.py
```

На macOS:

```bash
source .venv/bin/activate
python import_data.py
```

Если нужно быстро добавить только пользователей вручную, выполните в phpMyAdmin:

```sql
USE chitaigorod_demo;

INSERT IGNORE INTO roles (name) VALUES
('Администратор'),
('Менеджер'),
('Авторизированный клиент');

INSERT INTO users (role_id, full_name, login, password)
SELECT role_id, 'Никифорова Анна Семеновна', '94d5ous@gmail.com', 'uzWC67'
FROM roles WHERE name = 'Администратор'
ON DUPLICATE KEY UPDATE password = VALUES(password), full_name = VALUES(full_name);

INSERT INTO users (role_id, full_name, login, password)
SELECT role_id, 'Ситдикова Елена Анатольевна', 'ptec8ym@yahoo.com', 'LdNyos'
FROM roles WHERE name = 'Менеджер'
ON DUPLICATE KEY UPDATE password = VALUES(password), full_name = VALUES(full_name);

INSERT INTO users (role_id, full_name, login, password)
SELECT role_id, 'Никифорова Весения Николаевна', 'yzls62@outlook.com', 'JlFRCZ'
FROM roles WHERE name = 'Авторизированный клиент'
ON DUPLICATE KEY UPDATE password = VALUES(password), full_name = VALUES(full_name);
```

После этого можно входить:

```text
Администратор: 94d5ous@gmail.com / uzWC67
Менеджер: ptec8ym@yahoo.com / LdNyos
Клиент: yzls62@outlook.com / JlFRCZ
```

---

## Шаг 14. Проверьте роли
### Что делаем
Проверьте, что интерфейс отличается по роли.

### Команды/код
- **Гость** видит только список товаров.
- **Авторизированный клиент** видит список товаров.
- **Менеджер** видит список товаров, поиск, сортировку, фильтр и заказы.
- **Администратор** видит товары, поиск, сортировку, фильтр, добавление, редактирование, удаление и заказы.

---

## Шаг 15. Проверьте список товаров
### Что делаем
Убедитесь, что товары выводятся из базы данных.

### Команды/код
В списке отображаются:
- фото товара;
- артикул;
- наименование;
- категория;
- описание;
- производитель;
- поставщик;
- цена;
- единица измерения;
- количество на складе;
- действующая скидка.

Правила оформления:
- если скидка больше 25%, строка подсвечивается цветом `#23E1EF`;
- если товара нет на складе, строка подсвечивается серым;
- если есть скидка, старая цена красная и зачеркнутая, рядом показана итоговая цена.

---

## Шаг 16. Проверьте поиск, сортировку и фильтр
### Что делаем
Войдите под менеджером или администратором.

### Команды/код
Проверьте:
- поиск по текстовым полям;
- сортировку по цене;
- сортировку по количеству на складе;
- фильтр скидки `Все диапазоны`, `0-12,99%`, `13-16,99%`, `17% и более`.

Поиск, сортировка и фильтрация применяются сразу, без кнопки поиска.

---

## Шаг 17. Проверьте добавление и редактирование товара
### Что делаем
Войдите под администратором.

### Команды/код
Добавление товара:
1. Нажмите **Добавить товар**.
2. Заполните поля.
3. При необходимости выберите изображение.
4. Нажмите **Сохранить**.

Редактирование товара:
1. Дважды нажмите по товару.
2. Измените данные.
3. Нажмите **Сохранить**.

Ограничения:
- цена не может быть отрицательной;
- количество на складе не может быть отрицательным;
- нельзя открыть больше одной формы редактирования товара;
- новое изображение сохраняется в `resources/custom_images` и уменьшается до размера не больше `300x200`.

---

## Шаг 18. Проверьте удаление товара
### Что делаем
Войдите под администратором.

### Команды/код
1. Выберите товар.
2. Нажмите **Удалить товар**.
3. Подтвердите удаление.

Если товар есть в заказе, приложение покажет ошибку и не удалит товар.

---

## Шаг 19. Проверьте заказы
### Что делаем
Войдите под менеджером или администратором и нажмите **Заказы**.

### Команды/код
Менеджер может просматривать заказы.

Администратор может:
- добавлять заказ;
- редактировать заказ;
- удалять заказ.

Формат товаров в заказе:

```text
А112Т4, 2, G843H5, 1
```

---

## Шаг 20. Соберите исполняемый файл
### Что делаем
При необходимости соберите `.exe` через PyInstaller.

### Команды/код
```cmd
pyinstaller --noconfirm --windowed --name ChitaiGorod --icon resources\icon.ico --add-data "resources;resources" main.py
```

Готовый файл будет здесь:

```text
dist\ChitaiGorod\ChitaiGorod.exe
```

---

## Шаг 21. Подготовьте отчет
### Что делаем
Создайте `.docx` и вставьте скриншоты работы приложения.

### Команды/код
Добавьте скриншоты:
- окно входа;
- список товаров гостя;
- список товаров менеджера с поиском/фильтром;
- список товаров администратора;
- форма добавления или редактирования товара;
- список заказов;
- форма добавления или редактирования заказа.

---

## Шаг 22. Итоговые файлы для сдачи
### Что делаем
Передайте проект без архивации, если по заданию требуется структура файлов.

### Команды/код
В сдачу входят:
- `main.py`;
- `db.py`;
- `check_db.py`;
- `import_data.py`;
- `database.sql`;
- `requirements.txt`;
- `er_diagram.mmd` или экспортированная ER-диаграмма в PDF;
- папка `resources`;
- отчет со скриншотами;
- при необходимости папка `dist` с `.exe`.

---

## Контрольные SQL-запросы
### Что делаем
Проверьте количество данных после импорта.

### Команды/код
```sql
USE chitaigorod_demo;

SELECT 'roles' AS table_name, COUNT(*) AS cnt FROM roles
UNION ALL
SELECT 'users', COUNT(*) FROM users
UNION ALL
SELECT 'categories', COUNT(*) FROM categories
UNION ALL
SELECT 'suppliers', COUNT(*) FROM suppliers
UNION ALL
SELECT 'manufacturers', COUNT(*) FROM manufacturers
UNION ALL
SELECT 'products', COUNT(*) FROM products
UNION ALL
SELECT 'pickup_points', COUNT(*) FROM pickup_points
UNION ALL
SELECT 'orders', COUNT(*) FROM orders
UNION ALL
SELECT 'order_items', COUNT(*) FROM order_items;
```
